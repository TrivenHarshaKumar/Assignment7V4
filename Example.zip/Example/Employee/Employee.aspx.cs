﻿// Code-behind file that defines event handlers for the Employee.
using System;
using System.Collections.Specialized; // for class ListDictionary

public partial class Employee : System.Web.UI.Page
{
    // Submit Button adds a new Employee entry to the database,
    // clears the form and displays the updated list of Employee entries
    protected void submitButton_Click( object sender, EventArgs e )
   {
        // execute an INSERT  statement to add a new entry to the      
        // Messages table in the Employee Access Data Source
        EmployeeDataSource.InsertCommand = 
            "INSERT INTO [Employees] (" +

            "[EmployeeType]" + ", " +
            "[FirstName]" + ", " +
            "[LastName]" + ", " +
            "[BaseSalary]" + ", " +
            "[TSA]" + 

            ") VALUES (" +

            ToSql(RadioButtonListEmployeeType.Text) +", " +
            ToSql(TxtFirstname.Text) + ", " +
            ToSql(TxtLastname.Text) + ", " +
            ToSql(TxtBaseSalary.Text) + ", " +
            ToSql(TxtTSA.Text) +

            ")";

  
        EmployeeDataSource.Insert();

        // clear the TextBoxes
        clearTextBoxes();

      // update the GridView with the new database table contents
      EmployeeGridView.DataBind();
   } // submitButton_Click

    // format a string value for SQL
    private string ToSql(string stringValue)
    {
        return "'" + stringValue.Replace("'", "''") + "'";
    }

    // clear the TextBoxes
    private void clearTextBoxes()
    {
        TxtFirstname.Text = String.Empty;
        TxtLastname.Text = String.Empty;
        RadioButtonListEmployeeType.SelectedValue = "Faculty";
        TxtBaseSalary.Text = String.Empty;
        TxtTSA.Text = String.Empty;
    }

    // Clear Button clears the Web Form's TextBoxes
    protected void clearButton_Click( object sender, EventArgs e )
   {
        clearTextBoxes();
   } // clearButton_Click




    protected void TxtBaseSalary_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TxtTSA_TextChanged(object sender, EventArgs e)
    {

    }
} // end class Employee
